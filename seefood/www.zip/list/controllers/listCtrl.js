'use strict';

var app = angular.module('seeFoodApp');

app.controller('listCtrl', function() {
	console.log('listCtrl');
})