'use strict';

var app = angular.module('seeFoodApp');

app.controller('detailCtrl', function() {
	console.log('detailCtrl');
})